package cn.gx.entity;

/**
 * Created by guanxine on 16-4-17.
 */
public enum Rel {
    self,first,last,previous,next
}
