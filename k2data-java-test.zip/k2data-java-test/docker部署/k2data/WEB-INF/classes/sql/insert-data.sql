INSERT INTO courses (name,start,end,estimatedTime,facilitator) VALUES ("java","2016-4-10","2016-4-22",20,"shaonian");
INSERT INTO courses (name,start,end,estimatedTime,facilitator) VALUES ("php","2016-4-11","2016-4-22",20,"shaonian");
INSERT INTO courses (name,start,end,estimatedTime,facilitator) VALUES ("C++","2016-4-12","2016-4-22",20,"shaonian");
INSERT INTO courses (name,start,end,estimatedTime,facilitator) VALUES ("c#","2016-4-13","2016-4-22",20,"shaonian");
INSERT INTO courses (name,start,end,estimatedTime,facilitator) VALUES ("swift","2016-4-14","2016-4-22",20,"shaonian");
INSERT INTO courses (name,start,end,estimatedTime,facilitator) VALUES ("android","2016-4-15","2016-4-22",20,"shaonian");
INSERT INTO courses (name,start,end,estimatedTime,facilitator) VALUES ("python","2016-4-16","2016-4-22",20,"shaonian");